package Population;

import Country.Settlement;
import Location.Point;
import Simulation.Clock;

public class Vaccinated extends Person{
	private long vaccinationTime;
	
	public Vaccinated(int age, Point location, Settlement settlement, Long vaccinationTime) {
		super(age, location, settlement);
		this.vaccinationTime= vaccinationTime;

	}
	public long GetVaccinationTime(){return vaccinationTime;}
	public String tostring() {
		return super.toString() + " Vaccination Time:" + this.vaccinationTime;
	}
	public double contagionProbability() {
		long t= Clock.now() - this.vaccinationTime; 
		if(t<21) {
			double p = 0.56+ (0.15* Math.sqrt(21-t));
			return Math.min(1, p);
		}
		else {
			double k = 1.05 / (t-14);
			return Math.min(0.05, k);
		}
	}
	public String toString(){
		
		return  "Vaccinated: Age:" + GetAge() ;		
	}

	

}
