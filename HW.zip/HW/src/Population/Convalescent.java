package Population;
import Country.Settlement;
import Location.Point;
import Virus.IVirus;

public class Convalescent extends Person{
	private IVirus virus;

	public Convalescent(int age, Point location, Settlement settlement, IVirus virus){
		super(age, location, settlement);
		this.virus = virus;
	}
	public IVirus GetVirus() {return virus;}
	public String tostring() {
		return super.toString() + " Virus:"+ this.virus;
	}
	public double contagionProbability(){return 0.2;}
	public String toString(){
		
		return  "Convalescent: Age:" + GetAge() ;
		
	}

}
