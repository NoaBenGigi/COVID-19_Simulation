package Population;

import Country.Settlement;
import Location.Point;
import Simulation.Clock;

public class Healthy extends Person {

	public Healthy(int age, Point location, Settlement settlement) {
		super(age, location, settlement);
	}
	public String tostring() {
		return super.toString();
	}
	public Person vaccinate() {
		Vaccinated v = new Vaccinated(this.GetAge(),this.Getlocation(), this.GetSettlement(), Clock.now());
		return v;
		
	}
	public String toString(){
		
		return  "Healty: Age:" + GetAge() ;
		
	}


}
