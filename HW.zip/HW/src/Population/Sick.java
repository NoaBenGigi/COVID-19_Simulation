package Population;

import Country.Settlement;
import Location.Point;
import Virus.IVirus;

public class Sick extends Person{
	
	private long contagiousTime;
	private IVirus virus;
	public Sick(int age, Point location, Settlement settlement, long contagiousTime, IVirus virus) {
		super(age, location, settlement);
		this.contagiousTime= contagiousTime;
		this.virus= virus;
	}
	public long GetContagiousTime() {return contagiousTime;}
	public IVirus GetVirus(){return virus;}
	public String tostring() {
		return super.toString() + "  Contagious Time:" + this.contagiousTime+ " Virus:"+ this.virus;
	}
	public double contagionProbability() {
		throw new RuntimeException("Sick preson never get sick again!");
	}
	public Person contagion(IVirus virus) {
		throw new RuntimeException("Sick preson never get sick again!");
	}
	public Person recover() {
		Convalescent c= new Convalescent(this.GetAge(), this.Getlocation(),this.GetSettlement(), this.virus);
		return c;
	}
	public boolean tryToDie() {
		if(virus.tryToKill(this) == true){
			this.GetSettlement().killSucceeded();

			return true;
		}
		return false;
	}
	public String toString(){
		
		return  "Sick: Age:" + GetAge() ;
		
	}
}
