module HW {
	requires java.desktop;
}