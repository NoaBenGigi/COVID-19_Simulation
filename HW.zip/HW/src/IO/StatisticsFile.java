package IO;
import Country.City;
import Country.Kibbutz;
import Country.Map;

import java.io.*;
import java.util.Locale;

public class StatisticsFile{
    public void write(Map map) {
        try (PrintWriter writer = new PrintWriter(new File("test.csv"))) {
            StringBuilder sb = new StringBuilder();
            sb.append("Settlement Name");
            sb.append(',');
            sb.append("Settlement type");
            sb.append(',');
            sb.append("Ramzor Color");
            sb.append(',');
            sb.append("Sick People%");
            sb.append(',');
            sb.append("Vaccine Doses");
            sb.append(',');
            sb.append("Died People Number");
            sb.append(',');
            sb.append("People Number");
            sb.append(',');
            sb.append("\n");
            for(int i =0 ; i< map.GetSettlement().length;i++){
                sb.append(map.GetSettlement()[i].GetName());
                sb.append(",");
                if(map.GetSettlement()[i] instanceof City){
                    sb.append("City");
                }
                else if(map.GetSettlement()[i] instanceof Kibbutz){
                    sb.append("Kibbutz");
                }
                else{
                    sb.append("Moshav");
                }
                sb.append(",");
                sb.append(map.GetSettlement()[i].GetRamzorColor());
                sb.append(",");
                sb.append(map.GetSettlement()[i].GetSickPeopleList().size()/map.GetSettlement()[i].GetPeople().size());//number of sick people
                sb.append(",");
                sb.append(map.GetSettlement()[i].GetNumOfVaccineDoses());
                sb.append(",");
                sb.append(map.GetSettlement()[i].GetDiedNum());
                sb.append(",");
                sb.append(map.GetSettlement()[i].GetPeople().size());
                sb.append(",");
                sb.append("\n");
            }
            writer.write(sb.toString());
            writer.close();
        } catch ( FileNotFoundException e) {
            System.out.println(e.getMessage());
        }

    }

}
