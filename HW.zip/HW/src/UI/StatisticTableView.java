package UI;

import Country.Settlement;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableRowSorter;
import java.awt.*;

public class StatisticTableView extends JPanel {
    private JTextField tbFilterText; //text field for the sort
    private TableRowSorter<StatisticTableModel> sorter;
    private final StatisticTableModel model;
    public StatisticTableView(Settlement[] settlements) {
        model = new StatisticTableModel(settlements);   //create the model
        JTable table = new JTable(model);               //create the view
        this.setLayout(new BorderLayout());
        table.setRowSorter(sorter = new TableRowSorter<StatisticTableModel>(model));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setPreferredScrollableViewportSize(new Dimension(500, 70));
        table.setFillsViewportHeight(true);
        this.add(new JScrollPane(table));
        //tbFilterText.setSize(new Dimension(20,20));
        this.tbFilterText = new JTextField();
        this.add(tbFilterText,BorderLayout.BEFORE_LINE_BEGINS);
        tbFilterText.setToolTipText("Filter Name Column");
        tbFilterText.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {newFilter(model.getSelected_choice()); }
            public void removeUpdate(DocumentEvent e) { newFilter(model.getSelected_choice()); }
            public void changedUpdate(DocumentEvent e) { newFilter(model.getSelected_choice()); }
        });
        this.setPreferredSize(new Dimension(600,400));
    }

    public void setTbFilterText(JTextField tbFilterText) {
        this.tbFilterText = tbFilterText;
    }
    public JTextField getTbFilterText() {
        return tbFilterText;
    }
    public void newFilter(String colName) {
        try {
            sorter.setRowFilter(RowFilter.regexFilter(tbFilterText.getText(), model.getColIndex(colName)));
        } catch (java.util.regex.PatternSyntaxException e) {
            // If current expression doesn't parse, don't update.
        }
    }

}