package UI;
import Country.Settlement;
import Country.Map;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import IO.SimulationFile;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StatisticTableModel extends AbstractTableModel{
    private final SimulationFile s_file=SimulationFile.getInstance();
    private Settlement[] Settlement=s_file.GetMap().GetSettlement(); //the data
    private final Map map=s_file.GetMap();
    private final String[] columnNames = {"Settlement Name", "Settlement type", "Ramzor Color", "Sick People%",
            "Vaccine Doses", "Died People Number", "People Number"};
    private String selected_choice = "Settlement Name";

    public StatisticTableModel(Settlement[] Settlement) {
        this.Settlement = Settlement;
    }
    @Override
    public int getRowCount() { return Settlement.length; }
    @Override
    public int getColumnCount() { return 7; }
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Settlement one_settlement = map.at(rowIndex);
        return switch (columnIndex) {
            case 0 -> one_settlement.GetName();
            case 1 -> one_settlement.getClass();
            case 2 -> one_settlement.GetRamzorColor();
            case 3 -> one_settlement.GetSickPeopleList().size() / one_settlement.GetPeople().size();
            case 4 -> one_settlement.GetNumOfVaccineDoses();
            case 5 -> one_settlement.GetDiedNum();
            case 6 -> one_settlement.GetPeople().size();
            default -> null;
        };
    }
    @Override
    public String getColumnName(int column) { return columnNames[column]; }

    public int getColIndex(String name){
        String[] selected = StatisticsWindow.getInstance().getSelect();
        JComboBox<String> selected_combo = StatisticsWindow.getInstance().getSelect_combo();
        selected_combo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource() == selected_combo) {
                    switch (selected_combo.getItemAt(selected_combo.getSelectedIndex())) {
                        case "Settlement Name" -> selected_choice = "Settlement Name";
                        case "Settlement type" -> selected_choice = "Settlement type";
                        case "Ramzor Color" -> selected_choice = "Ramzor Color";
                        case "Vaccine Doses" -> selected_choice = "Vaccine Doses";
                    }
                }
            }
        });
        for(int i=0; i < columnNames.length;i++)
            if(selected_choice.equals(columnNames[i]))
                return i;
        return 0;
    }
    @Override
    public Class getColumnClass(int column) { return getValueAt(0, column).getClass(); }

    public String getSelected_choice(){return selected_choice;}
}
