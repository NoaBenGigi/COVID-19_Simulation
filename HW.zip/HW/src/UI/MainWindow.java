package UI;
import IO.SimulationFile;
import Simulation.Clock;
import Simulation.Main;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.lang.Object;

public class MainWindow extends JFrame {
    private static MainWindow mainWindow=null;
    public static MainWindow getInstance(){
        if(mainWindow == null) {
            mainWindow = new MainWindow();
        }
        return mainWindow;
    }
    protected MainWindow(){
        super("Main Window");
        this.setJMenuBar(new MenuBar());
        this.setLayout(new BorderLayout());
        JPanel sd_panel = new JPanel();
        JSlider slider_for_speed;
        final int FPS_MIN = 0;
        final int FPS_MAX = 30;
        final int FPS_INIT = 15;    //initial frames per second
        JSlider slider = new JSlider(JSlider.HORIZONTAL, 0, 50, 25);
        slider.setMinorTickSpacing(2);
        slider.setMajorTickSpacing(10);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);
        //slider.setSize(20,20);
        sd_panel.add(slider);
        //new_sd_panel.setSize(new Dimension(20,20));
        this.add(sd_panel, BorderLayout.PAGE_START);
        slider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent event) {
                int value = slider.getValue();
                Clock.SetTicksPerDays(value);
            }
        });
        this.pack();
        this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    public MainWindow GetRefOfMainWindow(){return this;}
    //@Override
    //public Dimension getPreferredSize() {
        //return new Dimension(200, 200);
    //}
}
