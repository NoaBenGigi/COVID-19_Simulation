package UI;

import Country.Map;
import Country.Settlement;
import IO.SimulationFile;
import Location.Location;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;

public class PanelDrawing extends JPanel {
    private final SimulationFile s_file = SimulationFile.getInstance();
    private final Settlement[] mapOfSettlements = s_file.GetMap().GetSettlement();
    int x1, x2, y1, y2;

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Font font = new Font("Tohoma", Font.PLAIN, 15);
        g.setFont(font);
        this.setBackground(Color.WHITE);
        if (s_file != null) {
            for (Settlement mapOfSettlement : mapOfSettlements) {
                x1 = mapOfSettlement.GetLocation().getPosition().getX();
                y1 = mapOfSettlement.GetLocation().getPosition().getY();
                x2 = x1 + mapOfSettlement.GetLocation().getSize().getWidth();
                y2 = y1 + mapOfSettlement.GetLocation().getSize().getHeight();
                g.setColor(mapOfSettlement.GetRamzorColor().GetColor());
                g.fillRect(x1, y1, x2, y2);
                g.setColor(Color.BLACK);
                g.drawString(mapOfSettlement.GetName(), x1, (y2 - y1) / 2 + y1);
            }
            this.addMouseListener(new RectClickListener());
        }
        Graphics2D gr = (Graphics2D) g;
        gr.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    }
    private static class RectClickListener implements MouseListener {
        private final SimulationFile s_file = SimulationFile.getInstance();
        private final Settlement[] mapOfSettlements = s_file.GetMap().GetSettlement();
        int x1, x2, y1, y2;
        @Override
        public void mouseClicked(MouseEvent e) {
            double Xclicked = e.getPoint().getX();
            double Yclicked = e.getPoint().getY();
            for (Settlement mapOfSettlement : mapOfSettlements) {
                x1 = mapOfSettlement.GetLocation().getPosition().getX();
                y1 = mapOfSettlement.GetLocation().getPosition().getY();
                x2 = x1 + mapOfSettlement.GetLocation().getSize().getWidth();
                y2 = y1 + mapOfSettlement.GetLocation().getSize().getHeight();
                if ((Xclicked >= x1 && Xclicked <= x2) && (Yclicked <= y2 && Yclicked >= y1)) {
                    StatisticsWindow st = StatisticsWindow.getInstance();
                    st.getTable().getTbFilterText().setText(mapOfSettlement.GetName());
                    st.getTable().newFilter("Settlement Name");
                    st.setVisible(true);
                }
            }
        }
        @Override
        public void mousePressed(MouseEvent e) {}

        @Override
        public void mouseReleased(MouseEvent e) {}

        @Override
        public void mouseEntered(MouseEvent e) {}

        @Override
        public void mouseExited(MouseEvent e) {}
    }
}

