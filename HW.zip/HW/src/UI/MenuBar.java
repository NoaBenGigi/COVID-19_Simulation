package UI;

import Country.Map;
import IO.SimulationFile;
import Simulation.Main;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.EventHandler;
import java.io.File;

public class MenuBar extends JMenuBar{
    private SimulationFile simulation=null;
    private StatisticsWindow statistic_win;
    //private MainWindow main_win=MainWindow.getInstance();
    public MenuBar(){
        super();
        boolean flag = false;
        JMenu menuFile = new JMenu("File");
        JMenuItem statistics= new JMenuItem("Statistics", KeyEvent.VK_T);

        JMenuItem load= new JMenuItem("Load", KeyEvent.VK_T);
        load.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                simulation = SimulationFile.getInstance();
                MainWindow main_win=MainWindow.getInstance();
                main_win.add(new PanelDrawing());
                main_win.setSize(1000,1000);
                main_win.revalidate();
                main_win.repaint();

                if(simulation != null){
                    load.setEnabled(false);
                    statistics.setEnabled(true);
                }
            }
        });
        menuFile.add(load);
        menuFile.addSeparator();

        statistics.setEnabled(simulation != null);
        statistics.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(simulation != null) {
                    simulation = SimulationFile.getInstance();
                    statistic_win= StatisticsWindow.getInstance();
                    statistic_win.setVisible(true);
                    statistic_win.setEnabled(true);
                    statistic_win.addWindowListener(new WindowListener() {
                        @Override
                        public void windowOpened(WindowEvent e) {
                            statistics.setEnabled(false);
                        }

                        @Override
                        public void windowClosing(WindowEvent e) {
                            statistics.setEnabled(true);

                        }

                        @Override
                        public void windowClosed(WindowEvent e) {
                        }

                        @Override
                        public void windowIconified(WindowEvent e) {

                        }

                        @Override
                        public void windowDeiconified(WindowEvent e) {

                        }

                        @Override
                        public void windowActivated(WindowEvent e) {

                        }

                        @Override
                        public void windowDeactivated(WindowEvent e) {

                        }

                    });
                }
            }
        });

        menuFile.add(statistics);
        menuFile.addSeparator();
        menuFile.add(new JMenuItem("Edit Mutations"));
        menuFile.addSeparator();

        JMenuItem exit= new JMenuItem("Exit", KeyEvent.VK_T);
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        menuFile.add(exit);
        JMenu menuSimulation = new JMenu("Simulation");
        menuSimulation.add(new JMenuItem("Play",new ImageIcon("src/Image/Play.png")));
        menuSimulation.addSeparator();
        menuSimulation.add(new JMenuItem("Pause",new ImageIcon("src/Image/Pause.png")));
        menuSimulation.addSeparator();
        menuSimulation.add(new JMenuItem("Stop",new ImageIcon("src/Image/Stop.png")));
        menuSimulation.addSeparator();

        JMenuItem ticksPerDays = new JMenuItem("Set Ticks Per Day");
        ticksPerDays.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JDialog ticks_panel = new JDialog(MainWindow.getInstance(),"Ticks Per Day",true);
                JLabel label = new JLabel("Ticks:");
                ticks_panel.add(label);
                label.setHorizontalAlignment(JLabel.CENTER);
                label.setSize(180,100);
                JSpinner s = new JSpinner();
                s.setBounds(70, 70, 50, 40);
                ticks_panel.setLayout(null);
                ticks_panel.add(s);
                ticks_panel.setSize(200, 200);
                JButton save= new JButton("Save"){
                    {
                        setSize(70, 30);
                        setMaximumSize(getSize());
                    }
                };
                ticks_panel.add(save);
                save.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {

                    }
                });
                ticks_panel.add(save);
                ticks_panel.show();
                ticks_panel.setDefaultCloseOperation(ticks_panel.HIDE_ON_CLOSE);
                ticks_panel.pack();
                ticks_panel.toFront();

            }
        });
        menuSimulation.add(ticksPerDays);
        JMenu menuHelp = new JMenu("Help");
        JMenuItem help = new JMenuItem("Help");
        help.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JDialog help_panel = new JDialog(MainWindow.getInstance(),"Help",true);
                JLabel help_label = new JLabel("<html>This program simulate the COVID-19 virus" +
                        "<br> In the program you can watch on demo of the virus and his impact on people" +
                        "<br> The user need to choose txt file that include map."+
                        "<br>In this program you can control on the speed of the simulation and see how the map change</html>");
                help_panel.add(help_label);
                help_panel.setDefaultCloseOperation(help_panel.HIDE_ON_CLOSE);
                help_panel.pack();
                help_panel.toFront();
                help_panel.setVisible(true);
            }
        });

        menuHelp.add(help);
        menuHelp.addSeparator();
        JMenuItem about = new JMenuItem("About");
        about.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JDialog about_panel = new JDialog(MainWindow.getInstance(),"Help",false);
                JLabel about_label = new JLabel("<html>This program is written by:"+
                                                            "<br>Noa Ben-Gigi" +
                                                            "<br> Lion Dahan" +
                                                            "<br>Date : 28/04/2021 </html>");
                about_panel.add(about_label);
                about_panel.setDefaultCloseOperation(about_panel.HIDE_ON_CLOSE);
                about_panel.pack();
                about_panel.toFront();
                about_panel.setVisible(true);
            }
        });
        menuHelp.add(about);
        this.add(menuFile);
        this.add(menuSimulation);
        this.add(menuHelp);

    }
}
