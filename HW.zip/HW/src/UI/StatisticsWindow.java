package UI;
import Country.Settlement;
import IO.SimulationFile;

import java.awt.*;
import javax.swing.*;
public class StatisticsWindow extends JDialog{
    private final JLabel lbPromat;
    private final JTextField tbPromat;
    private final SimulationFile s_file=SimulationFile.getInstance();
    private final Settlement[] mapOfSettlements=s_file.GetMap().GetSettlement();
    private static StatisticsWindow instance= null;
    private JComboBox<String> select_combo;
    private StatisticTableView table;
    private final String[] select={ "Settlement Name" ,"Settlement type", "Ramzor Color", "Vaccine Doses" };
    public static StatisticsWindow getInstance(){
        if(instance == null) {
            instance = new StatisticsWindow(MainWindow.getInstance());
        }
        return instance;
    }
    private StatisticsWindow(JFrame window){
        super(window,"Statistic Window ",false); //create new window
        this.setLayout(new BorderLayout());

        JPanel centerPanel = new JPanel();
        JPanel northPanel = new JPanel();
        JPanel southPanel = new JPanel();

        table =new StatisticTableView(mapOfSettlements);
        this.tbPromat = table.getTbFilterText();
        northPanel.setLayout(new BoxLayout(northPanel,BoxLayout.LINE_AXIS));
        select_combo= new JComboBox<String>(select);
        /*select_combo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource() == select_combo)
                    switch (select_combo.getItemAt(select_combo.getSelectedIndex()))
                        case "Settlement Name"
            }
        });*/
        northPanel.add(select_combo);

        northPanel.add(this.add(lbPromat = new JLabel("     Filter TextField:")));
        northPanel.add(this.add(tbPromat));

        this.add(northPanel, BorderLayout.PAGE_START);

        centerPanel.add(table);
        this.add(centerPanel,BorderLayout.CENTER);

        southPanel.setLayout(new BoxLayout(southPanel,BoxLayout.LINE_AXIS));
        southPanel.add(new JButton(("Save")));
        southPanel.add(new JButton("Add Sick"));
        southPanel.add(new JButton("Vaccinate"));
        this.add(southPanel, BorderLayout.SOUTH);

        this.pack();
        this.setDefaultCloseOperation(this.HIDE_ON_CLOSE);
        this.setVisible(true);
    }
    public String[] getSelect(){return select;}
    public JComboBox<String> getSelect_combo(){return select_combo;}
    public StatisticTableView getTable(){return table;}
}
