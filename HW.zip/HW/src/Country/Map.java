package Country;
import java.util.*;
import Population.Person;
import Population.Sick;
import Simulation.Clock;
import Virus.*;

public class Map {
	//This class described the map

	private Settlement[] settlements;
	public Map(Settlement[] settlements) {//constructor
		this.settlements=new Settlement[settlements.length];
		for(int i=0; i < settlements.length; i++){
			this.settlements[i]=settlements[i];
		}
	}
	public Map(List<Settlement> settlementList) {//constructor
		this.settlements = new Settlement[settlementList.size()];
		for(int i=0; i < settlements.length; i++){
			this.settlements[i]=settlementList.get(i);
		}
	}
	public Settlement[] GetSettlement() {return this.settlements;}

	public void printMap() {
		for(int i=0;i<this.settlements.length;i++)
			System.out.println(this.settlements[i].toString());
	}
	public void ResetMap() {//level 2 in main
		Settlement settlementNew;//Reference to a new settlement
		int size_of_new_settlement; //size of the new settlement(about to change in each iteration)
		Person person= null;
		// virus0= ChineseVariant
		// virus1= BritishVariant
		// virus2= SouthAfricanVariant
		Random rand1= new Random();
		int randomVirus;
		for(int i= 0 ;i< this.settlements.length; i++)
		{
			settlementNew= this.settlements[i];
			size_of_new_settlement= settlementNew.GetPeople().size();
			for (int j = 0; j <(int)(0.01*size_of_new_settlement);j++) {
				randomVirus= rand1.nextInt(3);
				if(!(settlementNew.GetPeople().get(j) instanceof Sick)) {
					if(randomVirus==0)
						person = settlementNew.GetPeople().get(j).contagion(new ChineseVariant());
					if(randomVirus==1)
						person = settlementNew.GetPeople().get(j).contagion(new BritishVariant());
					if(randomVirus==2)
						person = settlementNew.GetPeople().get(j).contagion(new SouthAfricanVariant());

					settlementNew.GetPeople().set(j, person);//switch between the old person to the new sick person.
				}
			}
			this.GetSettlement()[i].SetRamzorColor(this.GetSettlement()[i].calculateRamzorGrade());//update ramzor color for each settlement
			//the value we sent to the set returns from method calaculateRamzorGrade.
		}
	}
	public boolean SettlementByname(String settlementname){
		for(int i=0; i< settlements.length; i++){
			if( settlements[i].GetName().equals(settlementname))
				return true;
		}
		return false;
	}
	public int SettlementByIndex(String settlementname){
		for (int i=0; i<settlements.length;i++){
			if(settlements[i].GetName().equals(settlementname)){
				return i;

			}
		}
		return -1;
	}
	public Settlement at(int index){
		for(int i =0; i< settlements.length; i++)
		{
			while (i == index)
				return settlements[i];
		}
		return null;
	}
	public void simulation() {//Third level in the simulation
		Person p;//reference 
		Person new_sick;
		boolean check=false;
		Random rand1= new Random();
		int index;
		final int max_contagions=6;
		List<Person> people=new ArrayList<Person>();
		for(int i =0 ; i<5 ; i++) {//5 Simulations
			for(int j=0 ;j< this.settlements.length; j++) {
				for (int k=0; k<this.settlements[j].GetPeople().size();k++) {
					people.addAll(this.settlements[j].GetPeople()); // create a copy of the people list
					p = people.get(k);
					if(p instanceof Sick) {
						for(int c=0;c<max_contagions;c++) {
							index = rand1.nextInt(this.settlements[j].GetPeople().size());
							if(!(this.settlements[j].GetPeople().get(index) instanceof Sick)) {
								check=((Sick)p).GetVirus().tryToContagion(p, this.settlements[j].GetPeople().get(index));
								if(check) {
									new_sick=this.settlements[j].GetPeople().get(index).contagion(((Sick)p).GetVirus());
									this.settlements[j].GetPeople().remove(index);
									this.settlements[j].GetPeople().add(new_sick);
								}
							}
						}
					}
					Clock.nextTick();

					this.GetSettlement()[j].SetRamzorColor(this.GetSettlement()[j].calculateRamzorGrade());
				}
			}
		}
	}
}