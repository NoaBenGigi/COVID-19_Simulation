package Country;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import Population.Healthy;
import Population.Sick;
import Location.Location;
import Population.Person;
import Location.Point;


public class Settlement {
	private String name;
	private Location location;
	private List<Person> people;
	private RamzorColor ramzorcolor;
	private int max_people_num;
	private int vaccine_doses_num=0;
	private Settlement[] connected_settlements;
	private List<Settlement> neighbors;
	List<Person> sick_people=new ArrayList<Person>();
	List<Person> healthy_people=new ArrayList<Person>();
	private static int diedNum;
	public Settlement(String name, Location location, List<Person> people){
		this.name = name;
		this.location = location;
		this.people= new ArrayList<Person>(people);
		this.ramzorcolor= RamzorColor.Green;
	}
	public String GetName() {return this.name;}
	public Location GetLocation() {return this.location;}
	public List<Person> GetPeople(){return this.people;}
	public  int GetDiedNum(){return diedNum;}
	public RamzorColor GetRamzorColor() {return this.ramzorcolor;}
	public int GetMaxSickPeople(){return this.max_people_num;}
	public int GetNumOfVaccineDoses(){return this.vaccine_doses_num;}
	public void SetNeighbors(Settlement settlement1){this.neighbors.add(settlement1);}
	public void RemoveNeihbor(Settlement settlement1){this.neighbors.remove(settlement1);}
	public List<Settlement> GetNeighbors(){return this.neighbors;}
	public Settlement[] GetConnectedSettlements(){return this.connected_settlements;}
	public List<Person> GetHealthyPeopleList(){return this.healthy_people;}
	public List<Person> GetSickPeopleList(){return this.sick_people;}
	public String toString(){
		return "Name: "+ GetName() +","+ GetLocation() + ",Ramzor Color:"+ GetRamzorColor();
	}
	public void SetVaccineDosesNum(int vaccine_doses_num){
		this.vaccine_doses_num= vaccine_doses_num;
	}
	public void SetRamzorColor(RamzorColor nemRamzorColor) {
		this.ramzorcolor= nemRamzorColor;
	}
	public RamzorColor calculateRamzorGrade(){
		return ramzorcolor;
	}
	public double contagiousPercent() {
		int sum_of_sick_people=0;
		for (int i=0; i<people.size();i++) {
			if (people.get(i) instanceof Sick) {
				sum_of_sick_people++;
			}
		}
		return sum_of_sick_people/(double)people.size();
	}
	public boolean addPerson(Person p) {

		this.people.add(p);
		return true;
	}
	public boolean transferPerson(Person p, Settlement s) { //s - the new settlement, p - the person who transfer
		double multiplyStatistic;
		multiplyStatistic= s.GetRamzorColor().GetStatistic()*this.GetRamzorColor().GetStatistic();
		if(s.GetPeople().size()< s.max_people_num || multiplyStatistic > Math.random()){
			//if there is availability place in the new settlement
			//or if the multiply of two statistic is bigger then a random number between 0-1
			if (p instanceof Sick) {
				this.people.remove(p);//than remove this person
				s.sick_people.add(p);
				p.SetSettlement(s);
			}
			else if(p instanceof Healthy){
				this.people.remove(p);//than remove this person
				s.healthy_people.add(p);
				p.SetSettlement(s);
			}
		}
		else{
			return false;
			// from many reasons. 1- p is not Healthy and not Sick person. 2 -no availability place in s. 3- the statistic returns false
		}

		return true;// the transfer succeed
	}
	public Point randomLocation(){
		Random rand = new Random();
		int minX= location.getPosition().getX();
		int maxX=location.getSize().getWidth()+minX;
		int x= rand.nextInt(maxX-minX+1)+minX;
		Random rand1 = new Random();
		int minY= location.getPosition().getY();
		int maxY=location.getSize().getHeight()+minY;
		int y= rand1.nextInt(maxY-minY+1)+minY;
		Point p = new Point(x, y);
		return p;
	}
	public static void killSucceeded(){
		diedNum++;

	}


}
