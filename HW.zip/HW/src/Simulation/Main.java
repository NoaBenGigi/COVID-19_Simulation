//Assignment 1- 
//Noa Ben- Gigi ID:318355633
//Lion Dahan ID:318873338				
package Simulation;

import IO.SimulationFile;
//import Population.Person;
import java.awt.*;
import java.io.File;
import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;

import Country.Map;
import Exceptions.FileNotFound;
import UI.MainWindow;
import UI.PanelDrawing;
//import UI.Slider;
import UI.StatisticsWindow;

import javax.swing.*;

public class Main {
    public static void main(String[] args) throws IOException, FileNotFound {
        //File fileSrc = loadFileFunc();
        //Map map=SimulationFile.read(fileSrc); // The first level-loading the map
        //map.ResetMap();//Second level in simulation
        //map.simulation();//Third level in simulation
    	/*List<Person> people= new ArrayList<Person>();
    	 for(int i=0; i< map.GetSettlement().length; i++) {
    		people= map.GetSettlement()[i].GetPeople();
    		for(int j=0; j<people.size();j++) {
    			System.out.println(people.get(j).toString());
    		}
    		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~");
    	}*/
        MainWindow mainWindow = MainWindow.getInstance();
        //StatisticsWindow st=new StatisticsWindow(mainWindow);
        /*SimulationFile sw= SimulationFile.getInstance();
        SimulationFile.removeSimulation();
        sw=SimulationFile.getInstance();*/
        //map.printMap();
        //Slider sd= new Slider();
    }
    public static File loadFileFunc() {
        FileDialog fd = new FileDialog((Frame) null, "Please choose a file:", FileDialog.LOAD);
        fd.setVisible(true);
        if (fd.getFile() == null)
            return null;
        File f = new File(fd.getDirectory(), fd.getFile());
        System.out.println(f.getPath());
        return f;
    }
}